<?php

//app/Config/parameters.php

$parameters = array(
	'connect' => array(
		'host' 		=> 'localhost',
		'dbname'	=> 'site_commerce',
		'login' 	=> 'root',
		'password' 	=> ''
	)
);
//------
// echo '<pre>'; 
// print_r($parameters);
// echo '</pre>';
