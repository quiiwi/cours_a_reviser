<?php

//07-namespaces	
	//espace2.php
	
namespace Espace2;	
	
	
class A
{
	public function test2(){
		return 'Test 2';
	}
}

