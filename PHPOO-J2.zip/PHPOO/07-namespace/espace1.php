<?php
//07-namespaces	
	//espace1.php
	
namespace Espace1;	

class A
{
	public function test1(){
		return 'Test 1';
	}
}


