<?php
//08-autoload	
	//classA.php

class A
{
	public function __construct(){
		echo 'Instanciation de A !<hr/>'; 
	}
}