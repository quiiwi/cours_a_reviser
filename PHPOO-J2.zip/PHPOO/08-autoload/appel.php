<?php
//08-autoload	
	//appel.php

// require 'classA.php';
// require 'classB.php';
// require 'classC.php';
// require 'classD.php';
require 'autoload.php';

$a = new A;
$b = new B;
$c = new C;
$d = new D;

