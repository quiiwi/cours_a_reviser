<?php
//08-autoload	
	//classD.php

class D
{
	public function __construct(){
		echo 'Instanciation de D !<hr/>'; 
	}
}