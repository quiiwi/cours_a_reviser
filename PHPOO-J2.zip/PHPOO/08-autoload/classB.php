<?php
//08-autoload	
	//classB.php

class B
{
	public function __construct(){
		echo 'Instanciation de B !<hr/>'; 
	}
}