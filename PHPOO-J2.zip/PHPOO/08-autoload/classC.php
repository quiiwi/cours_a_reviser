<?php
//08-autoload	
	//classC.php

class C
{
	public function __construct(){
		echo 'Instanciation de C !<hr/>'; 
	}
}