<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Nos produits</title>
</head>
<body>
	
	<h1>Nos produits</h1>
	
	<a href="page2.php?article=jean&couleur=bleu&prix=10">Jean bleu</a><br>
	<a href="page2.php?article=robe&couleur=rouge&prix=20">Robe rouge</a><br>
	<a href="page2.php?article=pull&couleur=blanc&prix=30">Pull blanc</a><!-- après le "?" dans le href, on envoie des infos par l'url sur l'article choisi, à la page2.php qui les traite -->

</body>
</html>